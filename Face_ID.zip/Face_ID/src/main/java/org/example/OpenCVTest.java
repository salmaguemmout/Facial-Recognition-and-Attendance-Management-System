package org.example;

import org.opencv.core.Core;


public class OpenCVTest {
    public static void main(String[] args) {
        // Load the OpenCV native library
        System.load("C:\\Users\\Lenovo\\Downloads\\opencv\\build\\java\\x64\\opencv_java490.dll");

        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        // Test OpenCV
        System.out.println("OpenCV version: " + Core.VERSION);
    }
}
