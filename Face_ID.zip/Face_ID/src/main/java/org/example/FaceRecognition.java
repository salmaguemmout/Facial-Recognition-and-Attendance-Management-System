package org.example;
import org.bytedeco.javacv.*;
import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.opencv_face.*;
import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.objdetect.CascadeClassifier;

public class FaceRecognition {
    public static void main(String[] args) {
        // Load the OpenCV native library
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        // Load the pre-trained face detector (Haarcascades)
        CascadeClassifier faceCascade = new CascadeClassifier("C:\\Users\\Lenovo\\Downloads\\haarcascade_frontalface_alt.xml");
    }
}
